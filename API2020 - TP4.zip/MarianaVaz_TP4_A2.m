%A2.O script dever� mostrar, numa �nica janela (subplot de 2x3), as imagens bin�rias e
%perfis radiais das imagens forma1.jpg, forma2.jpg, forma3.jpg.

%Imagens Bin�rias
Imagem1 = 'Forma1.jpg';
Imagem2 = 'Forma2.jpg';
Imagem3 = 'Forma3.jpg';

%Extrai os perfiz radiais
PfRad1 = MarianaVaz_TP4_A1(Imagem1,0);
PfRad2 = MarianaVaz_TP4_A1(Imagem2,0);
PfRad3 = MarianaVaz_TP4_A1(Imagem3,0);

%Mostrar numa janela as IB e PfRad
figure(1)
subplot(2,3,1), imshow(Imagem1), title('Imagem Bin�ria - Forma1');
subplot(2,3,2), imshow(Imagem2), title('Imagem Bin�ria - Forma2');
subplot(2,3,3), imshow(Imagem3), title('Imagem Bin�ria - Forma3');
subplot(2,3,4), plot(PfRad1), title('Gr�fico do Perfil Radial da Imagem Bin�ria - Forma1');
subplot(2,3,5), plot(PfRad2), title('Gr�fico do Perfil Radial da Imagem Bin�ria - Forma2');
subplot(2,3,6), plot(PfRad3), title('Gr�fico do Perfil Radial da Imagem Bin�ria - Forma3');