%Abrir cada uma das imagens bin�rias fornecidas (3x7) e calcular as vari�veis atrav�s de C2. 
%O script dever� exportar os valores m�dios de cada classe para um ficheiro texto(xxx_TP4_treino.txt)

ficheiro = fopen('MarianaVaz_TP4_treino.txt', 'wt');
Nr_classe = {'03', '05', '08', '09', '11', '13', '23'};

for classe = 1:7
    r=0;
    c=0;
    e=0;
    s=0;
    a=0;
    p=0;
    v=0;
    m=0;
    mm=0;
    ca=0;
    for imagem = 1:3
        file = (['iPAD2_C', Nr_classe{classe},'_EX0', num2str(imagem),'_B.TIFF']);
        fich = imread(file);
        [r1, c1, e1, s1,a1,p1,v1,m1,mm1,ca1]= MarianaVaz_TP4_C2(fich);
        r=r+r1;
        c=c+c1;
        e=e+e1;
        s=s+s1; 
        a=a+a1;
        p=p+p1;
        v=v+v1;
        m=m+m1;
        mm=mm+mm1;
        ca = ca+ca1;
    end
    r = r/3;
    c = c/3;
    e = e/3;
    s = s/3;
    a = a/3;
    p = p/3;
    v = v/3;
    m = m/3;
    mm=mm/3;
    ca=ca/3;
    fprintf(ficheiro,'%f,%f,%f,%f,%f,%f,%f,%f,%f,%f\n',r, c, e, s,a,p,v,m,mm,ca);
    
end
fclose(ficheiro);