function [PfRad] = MarianaVaz_TP4_A1(file,graf)

%MarianaVaz_TP4_A1
%Fun��o para obter perfis radiais

IB = im2double(imread(file));
IB = imbinarize(IB);

%Dist�ncias do centroide � margem do objeto
[Ibound,L] = bwboundaries(IB,'noholes');
[PfRad,~] = signature(Ibound{1});

%Imagem bin�ria 
PP = regionprops(L,'Centroid','BoundingBox'); 
centroid = [PP.Centroid];
xCentroid = centroid(1:2:end);
yCentroid = centroid(2:2:end);
BB = PP.BoundingBox;

%Sub-imagem com o objeto e margem de 10 pixeis
Isub=IB;
Imsub=Isub(11:end-10, 11:end-10);
[~,L1] = bwboundaries(Imsub,'noholes');
RP = regionprops(L1,'Centroid','BoundingBox');
centroid_sub = [RP.Centroid];
xCentroid_sub = centroid_sub(1:2:end);
yCentroid_sub = centroid_sub(2:2:end);
BB_sub = RP.BoundingBox;

if graf == 1
    figure(1)
    subplot(3,1,1), imshow(IB)
    hold on
    rectangle('Position', BB, 'EdgeColor', 'r','LineWidth', 1); 
    hold on
    plot(xCentroid,yCentroid,'b*');
    title('Imagem Bin�ria com centroide(azul) e Bounding Box(vermelho)'); 
    subplot(3,1,2), imshow(Imsub)
    hold on
    rectangle('Position', BB_sub, 'EdgeColor', 'r','LineWidth', 1); 
    hold on
    plot(xCentroid_sub,yCentroid_sub,'b*');
    hold off
    title('Sub-Imagem com centroide(azul) e Bounding Box(vermelho)'); 
    subplot(3,1,3), plot(PfRad), title('Gr�fico da dist�ncia radial');   
    
end

end

