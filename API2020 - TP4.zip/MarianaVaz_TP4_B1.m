function [r,c,e,s] = MarianaVaz_TP4_B1(file,graf)

%MarianaVaz_TP4_B1
% Fun��o que retorna par�metros de forma: retangularidade(r), circularidade(c), excentricidade(e) e solidez(s)

IB = imread(file);
IB = imbinarize(IB);

PP = regionprops('struct',IB,'Centroid', 'BoundingBox','Extent','Perimeter','Eccentricity','Solidity','EquivDiameter');

%Centroid e BoundingBox
centroid = [PP.Centroid];
xCentroid = centroid(1:2:end);
yCentroid = centroid(2:2:end);
BB = PP.BoundingBox;

%r,c,e,s
r = max(cat(1,PP.Extent));
p = max(cat(1,PP.Perimeter));
v = max(cat(1,PP.EquivDiameter));
raio = v/2;
c = (2 * pi * raio) ./ (p) ;
if c >= 1
    c = 1;
end
e = max(cat(1,PP.Eccentricity));
s = max(cat(1,PP.Solidity));

if graf == 1
    figure(1)
    imshow(IB)
    hold on
    bb = rectangle('Position', BB, 'EdgeColor', 'y','LineWidth', 1); 
    bb.LineStyle= '--';
    plot(xCentroid,yCentroid,'b*');
    title(['Imagem Bin�ria com Centroide e Boundig Box  ','  Retangularidade:   ', num2str(r), '  Circularidade:  ', num2str(c), '  Solidez:  ', num2str(s),'  Excentricidade:  ', num2str(e)]);
    hold off
    legend('Centroide','Location','northwest');
    
end
end

