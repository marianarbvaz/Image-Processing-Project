%O script dever� mostrar, numa �nica janela (subplot de 2x2), as imagens bin�rias e
%os 4 par�metros de forma para 4 imagens: forma1.jpg, �2�, �3�, forma4.jpg.

%Imagens Bin�rias
Imagem1 = 'Forma1.jpg';
Imagem2 = 'Forma2.jpg';
Imagem3 = 'Forma3.jpg';
Imagem4 = 'Forma4.jpg';

%Extrair os parametros de forma
[r1,c1,e1,s1]= MarianaVaz_TP4_B1(Imagem1,0);
[r2,c2,e2,s2] = MarianaVaz_TP4_B1(Imagem2,0);
[r3,c3,e3,s3] = MarianaVaz_TP4_B1(Imagem3,0);
[r4,c4,e4,s4] = MarianaVaz_TP4_B1(Imagem4,0);

figure(1)
subplot(4,1,1),imshow(Imagem1), title(['Imagem Bin�ria da Forma1 - Par�metros de Forma: r = ', num2str(r1),' | c = ',num2str(c1),' | e = ', num2str(e1),' | s = ', num2str(s1)]);
subplot(4,1,2),imshow(Imagem2), title(['Imagem Bin�ria da Forma2 - Par�metros de Forma: r = ', num2str(r2),' | c = ',num2str(c2),' | e = ', num2str(e2),' | s = ', num2str(s2)]);
subplot(4,1,3),imshow(Imagem3), title(['Imagem Bin�ria da Forma3 - Par�metros de Forma: r = ', num2str(r3),' | c = ',num2str(c3),' | e = ', num2str(e3),' | s = ', num2str(s3)]);
subplot(4,1,4),imshow(Imagem4), title(['Imagem Bin�ria da Forma4 - Par�metros de Forma: r = ', num2str(r4),' | c = ',num2str(c4),' | e = ', num2str(e4),' | s = ', num2str(s4)]);

