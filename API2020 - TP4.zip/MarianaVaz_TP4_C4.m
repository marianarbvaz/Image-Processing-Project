function [C1No] = MarianaVaz_TP4_C4(fich,graf)

%Mariana_TP4_C4
%Para processar a imagem lida e devolver o No da classe a que pertence(ClNo)

RGB = imread(fich);
IB = MarianaVaz_TP4_C1(fich);
train = load('MarianaVaz_TP4_treino.txt');

for i=1:7
    [r,c,e,s,~,p,v,m,mm,~] = MarianaVaz_TP4_C2(IB);
    diferencas(i) = abs(r - train(i,1,:)) + abs(c-train(i,2,:)) + abs(e-train(i,3,:)) + abs(s-train(i,4,:)) + abs(log(v)-log(train(i,7,:))) + abs(log(p)-log(train(i,6,:))) +  abs(log(m)-log(train(i,8,:))) + abs(log(mm)-log(train(i,9,:)));
end

dif_minima = find(diferencas == min(diferencas(:)));

classe={'03', '05', '08', '09', '11', '13', '23'};
nomes={'Populus nigra', 'Quercus rour', 'Nerium oleander', 'Betula pubescens', 'Acer palmaturu', 'Corylus avellana', 'Erodium sp'};
C1No = classe{dif_minima};
N = nomes{dif_minima};

if graf == 1
    subplot(2,1,1), imshow(RGB); %imagem original RGB
    subplot(2,1,2), imshow(IB), title(['Classe -  ', N, '   N�mero da Classe -  ', C1No]);
    
end

