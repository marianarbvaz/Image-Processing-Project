function [IB] = MarianaVaz_TP4_C1(Nomefich)

%MarianaVaz_TP4_C1
%sele��o de um �nico objeto por segmenta��o, binariza��o e simplifica��o

IO = imread(Nomefich);
IM = rgb2hsv(IO);
[NL, NC, ~] = size(IM);
linha = NL/2;
coluna = NC/2;
seccao = IM(linha - NL*0.25: linha + NL*0.25, coluna - NC*0.25 : coluna + NC*0.25,:);

R = seccao(:,:,1);
R = imadjust(R);
V = seccao(:,:,2);
V = imadjust(V);

r = std(R(:));
s = std(V(:));
v = s/r;

if v > 0.87
    if (1.22 > v) 
        IM_grey = IM(:,:,3);
        IB = 1-imbinarize(IM_grey);
    else
        IM_grey = IM(:,:,2);
        IB = imbinarize(IM_grey);
    end
else
  
  IM_grey = IM(:,:,1);
  IB = 1-imbinarize(IM_grey);
    
end

%Opera��es Morfol�gicas
IB = imfill(IB, 'holes');
IB = imerode(IB, strel('disk',3));
IB = imfill(IB, 'holes');
IB = imclose(IB, strel('disk',11));
IB = bwmorph(IB, 'bridge',Inf);
IB = bwmorph(IB, 'majority',Inf);
IB = imfill(IB, 'holes');
IB = imdilate(IB, strel('disk',6));
IB = imclose(IB, strel('disk',3));
IB = imclose(IB, strel('disk',6));
IB = bwpropfilt(IB,'Area',1);
IB = bwmorph(IB, 'bridge',Inf);
IB = bwmorph(IB, 'majority',Inf);

end

