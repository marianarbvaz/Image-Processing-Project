function [r,c,e,s,a,p,v,m,mm,ca] = MarianaVaz_TP4_C2(IB)

%MarianaVaz_TP4_C2
%Fun��o MATLAB que recebe de input uma imagem bin�ria e devolve um vetor com vari�veis de forma relevantes para a classifica��o

%Resize do objeto
Props = regionprops('struct',IB,'BoundingBox');
BB = Props.BoundingBox;
c_min = BB(1);
c_max = c_min + BB(3);
l_min = BB(2);
l_max = l_min + BB(4) ;

Obj = IB(l_min:l_max , c_min:c_max);
[NL,NC] = size(Obj);
if NL > NC
    size_max=NL;
else
    size_max=NC;
end
escala = 500/size_max;
IB_r=imresize(Obj,escala);

%Propriedades de forma 
PP = regionprops('struct',IB_r,'Extent','Perimeter','Area','Eccentricity','Solidity','EquivDiameter','Extrema','MinorAxisLength','MajorAxisLength', 'ConvexArea');
r = max(cat(1,PP.Extent));
p = max(cat(1,PP.Perimeter));
v = max(cat(1,PP.EquivDiameter));
raio = v/2;
c = (2 * pi * raio) ./ (p) ;
if c >= 1
    c=1;
end
e = max(cat(1,PP.Eccentricity));
s = max(cat(1,PP.Solidity));
a = max(cat(1,PP.Area));
m = max(cat(1,PP.MinorAxisLength));
mm = max(cat(1,PP.MajorAxisLength));
ca = max(cat(1,PP.ConvexArea));

end
